<?php
session_start();
include_once "templates/database.php";
include_once "templates/header.php";
?>

<body class="bg-primary">
    <div id="layoutAuthentication">
        <div id="layoutAuthentication_content">
            <main>
                <div class="container">
                    <div class="row justify-content-center">
                        <div class="col-lg-5">
                            <div class="card shadow-lg border-0 rounded-lg mt-5">
                                <div class="card-header">
                                    <h3 class="text-center font-weight-light my-4">Login</h3>
                                </div>
                                <div class="card-body">
                                    <form action="" method="POST">
                                        <div class="form-floating mb-3">
                                            <input class="form-control" name="email" id="inputEmail" type="email"
                                                placeholder="name@example.com" />
                                            <label for="inputEmail">Email address</label>
                                        </div>
                                        <div class="form-floating mb-3">
                                            <input class="form-control" name="password" id="inputPassword" type="password"
                                                placeholder="Password" />
                                            <label for="inputPassword">Password</label>
                                        </div>
                                        <div class="d-flex align-items-center justify-content-between mt-4 mb-0">
                                            <a class="btn btn-primary" name="submit" value="login" type="submit" href="index.php">Login</a>
                                        </div>
                                        <span>email: admin@gmail.com</span>
                                        <span>password: admin</span>
                                    </form>
                                    <?php
                                    if(isset($_POST["submit"])) {
                                        $email = mysqli_real_escape_string($conn, $_POST["email"]);
                                        $password = mysqli_real_escape_string($conn, $_POST["password"]);
                                        $check = mysqli_query($conn, "SELECT * FROM admin WHERE email = '$email' AND password = '$password' ");

                                        if(mysqli_num_rows($check) > 0) {
                                            $obj = mysqli_fetch_object($check);
                                            $_SESSION["status_login"] = true;
                                            $_SESSION["a_global"] = $obj;
                                            $_SESSION["id"] = $obj->$id;
                                            echo '<script>window.location="index.php"</script>';
                                        } else {
                                            echo '<script>alert("Email or password is wrong!")</script>';
                                        }
                                    }
                                    ?>
                                </div>
                                <div class="card-footer text-center py-3">
                                    <div class="small"><a href="register.php">Need an account? Sign up!</a></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </main>
        </div>
        <div id="layoutAuthentication_footer">
            <?php
            include_once 'templates/footer.php';
            ?>
        </div>
    </div>
    <?php
    include_once 'templates/script.php';
    ?>
</body>

</html>